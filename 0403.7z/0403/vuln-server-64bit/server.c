#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define SERVER_PORT 9999
#define LISTENQ (1024+512)
#define MAX_CHILDREN 1

struct sockaddr_in servaddr;
int sock_fd;

void create_tcp_socket(void) {
  if((sock_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
    printf("Can't create TCP socket!!!\n\n");
    exit(-1);
  }
}

void wait_a_child(void){
   int status;
   if( waitpid(-1, &status, 0) == -1){
      printf("wait_a_child returned -1!!!\n\n");
      exit(-1);
   }
}

void vulnerable_function(char *srcbuff, int lsrcbuff, int sock_c){
   char buff[48];

   // Simulate a reasonable processing time
   //usleep( 200000 ); /* Sleep 200000 micro seconds = 200 ms */

   // Simulate process the request (Buffer overflow)
   memcpy(buff, srcbuff, lsrcbuff);
}

char g_cmd[16] = "/bin/bash";
char g_para[8] = "-i";
char * g_buff[] = {g_cmd, g_para, 0};

void local_rop(int sock_c){
   dup2(sock_c, 0);
   dup2(sock_c, 1);
   dup2(sock_c, 2);

   execve(g_cmd, g_buff, 0);
   asm __volatile__ (".byte 0x5F,0xC3,0x5E,0xC3,0x5A,0xC3,0x59,0xC3,0x58,0xC3,0x0F,0x05,0xC3");
}

void startServer(void){
   create_tcp_socket();

   /*  Populate socket address structure  */
   memset(&servaddr, 0, sizeof(servaddr));
   servaddr.sin_family      = AF_INET;
   servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
   servaddr.sin_port        = htons(SERVER_PORT);

   /*  Assign socket address to socket  */
   if ( bind(sock_fd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0 ){
       printf("Couldn't bind listening socket!!!\n\n");
       exit(-1);
   }

   /*  Make socket a listening socket  */
   if ( listen(sock_fd, LISTENQ) < 0 ){
       printf("Call to listen failed!!!\n\n");
       exit(-1);
   }
}

void attend_non_return(void){
   int sock_c;
   int res;
   static char buf[1024];
   char msg1[]="Welcome to a simple webserver!\n";
   char msg2[]="All done, bye!\n";
   struct timeval tv;


   write(1,".", 1);
   if ( (sock_c = accept(sock_fd, NULL, NULL)) < 0 ){
      printf("Error calling accept()!!!\n\n");
      exit(-1);
   }
   close(sock_fd);
   printf("---sock_fd:%d, sock:%d, local_rop:%p---\n", sock_fd, sock_c, local_rop);

   // You can optimize waiting via timeout
   tv.tv_sec=0,tv.tv_usec=400000; //400ms timeout
   if ( (setsockopt(sock_c,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv))) != 0){
      printf("setsockopt() error!!!\n\n");
      exit(-1);
   }

   // Read from client (not be used for anything)
   res = read(sock_c, buf, sizeof(buf));
   if(res <= 0){
      printf("Error reading from request client!!!\n\n");
      exit(-1);
   }
  
   // Send banner to client
   res = write(sock_c, msg1, strlen(msg1));
   if( res <= 0){
      printf("Error sending banner to client!!!\n\n");
      exit(-1);
   }

   // Read payload from client
   res = read(sock_c, buf, sizeof(buf));

   // Functions which contain a buffer overflow
   vulnerable_function(buf, res, sock_c);

    // If all was right print bye msg
   write(sock_c, msg2, strlen(msg2));

   close(sock_c);
   printf("Exit child!!!\n\n");
   exit(0);
}

int main(void){
   pid_t pid;
   int children = 0;

   printf("Starting server on port [%d]\n", SERVER_PORT);
   startServer();

   while(1){
      if(MAX_CHILDREN <= children){
         wait_a_child();
         children--;
      }
      pid = fork();

      if(pid<0){
         printf("fork() failed!!!\n\n");
         exit(-1);
      }

      if (pid == 0)
         attend_non_return();

      children++;
   }

   return 0;
} 
